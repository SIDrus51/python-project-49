#!/scr/bin/env python3
import random
import prompt
score = 3

def game_logic():
    print('Welcome to the Brain Games!')
    name = prompt.string('May I have your name? ')
    print(f'Hello, {name}')
    print('Answer "yes" if the number is even, otherwise answer "no".')
    random_num = random.randint(1, 100)
    print(f'Question: {random_num}')
    user_answer = input()


if __name__ == '__main__'
    main()
