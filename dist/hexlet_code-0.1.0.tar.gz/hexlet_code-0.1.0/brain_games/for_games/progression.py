from random import randint
import range
overview = ('What number is missing in the progression?')


def correct_answer():
    num_1 = randint(1,20) #число
    num_2 = randint(1,10) #шаг
    n = randint(5, 10) #длина
    progression = [num_1 + num_2 * i for i in range(n)]
    question = f'{progression}'
    index = random.randint(0, len(progression) - 1)
    cor_answer = progression[index]
    progression[index] = ".."
    return progression, cor_answer
