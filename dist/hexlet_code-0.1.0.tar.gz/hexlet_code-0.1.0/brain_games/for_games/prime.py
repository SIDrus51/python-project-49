from random import randint

overview = ('Answer "yes" if given number is prime. Otherwise answer "no".')

def correct_answer():
    question = (f'{randint(1, 100)}')
    Correct_answer = is_prime(question)
    return question, Correct_answer


def is_prime(question):
    a = int(question)
    if a % a == 0 and a != 0:
        return 'yes'
    else:
        return 'no'

