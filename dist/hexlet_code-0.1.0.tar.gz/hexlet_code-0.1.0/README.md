### Hexlet tests and linter status:
[![Actions Status](https://github.com/SIDrus51/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/SIDrus51/python-project-49/actions)

<a href="https://codeclimate.com/github/SIDrus51/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/50d053427c384add6e45/maintainability" /></a>

### asciinema
[![asciicast](https://asciinema.org/a/lcj8qPc4dpBotK7QGNwEnXRpi)]
[![asciicast](https://asciinema.org/a/kuGixQvxnl4MhH581kiJIM6hR.svg)](https://asciinema.org/a/kuGixQvxnl4MhH581kiJIM6hR)
[![asciicast](https://asciinema.org/a/9X1zXByq2xjbP0SiukebNh048.svg)](https://asciinema.org/a/9X1zXByq2xjbP0SiukebNh048)
[![asciicast](https://asciinema.org/a/RJHtVChy4s9XS995BG6vRulMv.svg)](https://asciinema.org/a/RJHtVChy4s9XS995BG6vRulMv)
